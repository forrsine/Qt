#include "databasemanager.h"
#include <QDebug>

DataBaseManager* DataBaseManager::m_instance = nullptr;

DataBaseManager::DataBaseManager()
{
    // 连接SQLite数据库（文件型数据库，无需服务器）
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName("hospital_system.db"); // 数据库文件存储在程序运行目录

    // 打开数据库
    if (!m_db.open()) {
        qCritical() << "数据库连接失败：" << m_db.lastError().text();
    } else {
        qDebug() << "数据库连接成功";
        createTables(); // 自动创建数据表
        // 初始化默认管理员账户（用户名：admin，密码：123456）
        QSqlQuery query;
        // 先检查 User 表是否存在数据
        query.exec("SELECT * FROM User");
        if (!query.next()) {  // 如果表为空，插入默认管理员
            query.prepare("INSERT INTO User (USERNAME, PASSWORD, FULLNAME) VALUES (?, ?, ?)");
            query.addBindValue("admin");
            query.addBindValue("123456");
            query.addBindValue("系统管理员");
            if (query.exec()) {
                qDebug() << "默认管理员账户创建成功";
            } else {
                qCritical() << "创建管理员失败：" << query.lastError().text();
            }
        }
    }
}

DataBaseManager* DataBaseManager::getInstance()
{
    if (!m_instance) {
        m_instance = new DataBaseManager();
    }
    return m_instance;
}

DataBaseManager::~DataBaseManager()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
    delete m_instance;
}

bool DataBaseManager::isConnected() const
{
    return m_db.isOpen();
}

bool DataBaseManager::createTables()
{
    QSqlQuery query;
    QStringList createSqls;

    // 1. 用户表（User）
    createSqls << R"(
    CREATE TABLE IF NOT EXISTS User (
        ID INTEGER PRIMARY KEY AUTOINCREMENT,  -- 改为 INTEGER
        USERNAME TEXT UNIQUE NOT NULL,
        PASSWORD TEXT NOT NULL,
        FULLNAME TEXT NOT NULL
    )
)";

    // 2. 患者表（Patient）
    createSqls << R"(
        CREATE TABLE IF NOT EXISTS Patient (
            ID TEXT PRIMARY KEY,
            ID_CARD TEXT(20) UNIQUE NOT NULL,
            NAME TEXT NOT NULL,
            SEX INTEGER NOT NULL, -- 0:女，1:男
            DOB TEXT NOT NULL, -- 出生日期（格式：yyyy/MM/dd）
            HEIGHT REAL NOT NULL,
            WEIGHT REAL NOT NULL,
            MOBILEPHONE TEXT NOT NULL,
            AGE INTEGER NOT NULL,
            CREATEDTIMESTAMP TEXT NOT NULL
        )
    )";

    // 3. 操作记录表（History）
    createSqls << R"(
        CREATE TABLE IF NOT EXISTS History (
            ID TEXT PRIMARY KEY AUTOINCREMENT,
            USER_ID TEXT NOT NULL,
            USERNAME TEXT NOT NULL,
            EVENT TEXT NOT NULL,
            TIMESTAMP TEXT NOT NULL,
            FOREIGN KEY (USER_ID) REFERENCES User(ID)
        )
    )";

    // 4. 科室表（Department）- 选做
    createSqls << R"(
        CREATE TABLE IF NOT EXISTS Department (
            ID TEXT PRIMARY KEY,
            NAME TEXT UNIQUE NOT NULL
        )
    )";

    // 5. 医生表（Doctor）- 选做
    createSqls << R"(
        CREATE TABLE IF NOT EXISTS Doctor (
            ID TEXT PRIMARY KEY,
            EMPLOYEENO TEXT UNIQUE NOT NULL,
            NAME TEXT NOT NULL,
            DEPARTMENT_D TEXT NOT NULL,
            FOREIGN KEY (DEPARTMENT_D) REFERENCES Department(ID)
        )
    )";

    // 执行所有创建表SQL
    foreach (const QString& sql, createSqls) {
        if (!query.exec(sql)) {
            qCritical() << "创建表失败：" << query.lastError().text();
            return false;
        }
    }
    return true;
}

bool DataBaseManager::verifyLogin(const QString &username, const QString &password)
{
    QSqlQuery query;
    query.prepare("SELECT * FROM User WHERE USERNAME=? AND PASSWORD=?");
    query.addBindValue(username);
    query.addBindValue(password);
    query.exec();
    return query.next();
}

QSqlQuery DataBaseManager::getPatients(const QString &queryStr)
{
    QSqlQuery query;
    if (queryStr.isEmpty()) {
        query.exec("SELECT * FROM Patient ORDER BY CREATEDTIMESTAMP DESC");
    } else {
        // 支持按姓名、身份证、手机号查询
        QString sql = QString("SELECT * FROM Patient WHERE NAME LIKE '%%1%' OR ID_CARD LIKE '%%1%' OR MOBILEPHONE LIKE '%%1%'")
                          .arg(queryStr);
        query.exec(sql);
    }
    return query;
}

bool DataBaseManager::addPatient(const QString &id, const QString &idCard, const QString &name, int sex, const QString &dob, double height, double weight, const QString &phone, int age)
{
    QSqlQuery query;
    query.prepare(R"(
        INSERT INTO Patient (ID, ID_CARD, NAME, SEX, DOB, HEIGHT, WEIGHT, MOBILEPHONE, AGE, CREATEDTIMESTAMP)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    )");
    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    query.addBindValue(id);
    query.addBindValue(idCard);
    query.addBindValue(name);
    query.addBindValue(sex);
    query.addBindValue(dob);
    query.addBindValue(height);
    query.addBindValue(weight);
    query.addBindValue(phone);
    query.addBindValue(age);
    query.addBindValue(timestamp);

    bool success = query.exec();
    if (!success) {
        qCritical() << "添加患者失败：" << query.lastError().text();
    }
    return success;
}

bool DataBaseManager::updatePatient(const QString &id, const QString &idCard, const QString &name, int sex, const QString &dob, double height, double weight, const QString &phone, int age)
{
    QSqlQuery query;
    query.prepare(R"(
        UPDATE Patient SET ID_CARD=?, NAME=?, SEX=?, DOB=?, HEIGHT=?, WEIGHT=?, MOBILEPHONE=?, AGE=?
        WHERE ID=?
    )");
    query.addBindValue(idCard);
    query.addBindValue(name);
    query.addBindValue(sex);
    query.addBindValue(dob);
    query.addBindValue(height);
    query.addBindValue(weight);
    query.addBindValue(phone);
    query.addBindValue(age);
    query.addBindValue(id);

    bool success = query.exec();
    if (!success) {
        qCritical() << "修改患者失败：" << query.lastError().text();
    }
    return success;
}

bool DataBaseManager::deletePatient(const QString &id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM Patient WHERE ID=?");
    query.addBindValue(id);

    bool success = query.exec();
    if (!success) {
        qCritical() << "删除患者失败：" << query.lastError().text();
    }
    return success;
}

bool DataBaseManager::addOperationRecord(const QString &userId, const QString &username, const QString &event)
{
    QSqlQuery query;
    query.prepare(R"(
        INSERT INTO History (USER_ID, USERNAME, EVENT, TIMESTAMP)
        VALUES (?, ?, ?, ?)
    )");
    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    query.addBindValue(userId);
    query.addBindValue(username);
    query.addBindValue(event);
    query.addBindValue(timestamp);

    bool success = query.exec();
    if (!success) {
        qCritical() << "添加操作记录失败：" << query.lastError().text();
    }
    return success;
}
