#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTableWidget>
#include <QComboBox>
#include <QDateEdit>
#include <QMessageBox>
#include <QSqlQueryModel>
#include "databasemanager.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    // 初始化所有界面
    void initUI();
    // 创建登录界面
    QWidget* createLoginWidget();
    // 创建主界面
    QWidget* createMainWidget();
    // 创建患者管理界面
    QWidget* createPatientManagerWidget();
    // 创建患者编辑界面（添加/修改）
    QWidget* createPatientEditWidget(bool isAdd = true);

    // 刷新患者列表
    void refreshPatientList(const QString& queryStr = "");
    // 清空编辑表单
    void clearEditForm();

private slots:
    // 登录相关槽函数
    void onLoginBtnClicked();
    void onRegisterBtnClicked();

    // 主界面导航槽函数
    void onPatientManagerBtnClicked();
    void onDepartmentManagerBtnClicked(); // 选做
    void onDoctorManagerBtnClicked();     // 选做

    // 患者管理槽函数
    void onQueryPatientBtnClicked();
    void onAddPatientBtnClicked();
    void onEditPatientBtnClicked();
    void onDeletePatientBtnClicked();
    void onSavePatientBtnClicked();
    void onCancelEditBtnClicked();

private:
    QStackedWidget* m_stackedWidget; // 界面切换容器

    // 登录界面组件
    QLineEdit* m_loginUsernameEdit;
    QLineEdit* m_loginPasswordEdit;

    // 患者管理界面组件
    QLineEdit* m_patientQueryEdit;
    QTableWidget* m_patientTable;
    QPushButton* m_queryPatientBtn;
    QPushButton* m_addPatientBtn;
    QPushButton* m_editPatientBtn;
    QPushButton* m_deletePatientBtn;

    // 患者编辑界面组件
    QLineEdit* m_editIdEdit;
    QLineEdit* m_editIdCardEdit;
    QLineEdit* m_editNameEdit;
    QComboBox* m_editSexCombo;
    QDateEdit* m_editDobEdit;
    QLineEdit* m_editHeightEdit;
    QLineEdit* m_editWeightEdit;
    QLineEdit* m_editPhoneEdit;
    QLineEdit* m_editAgeEdit;
    QPushButton* m_savePatientBtn;
    QPushButton* m_cancelEditBtn;

    bool m_isAddMode; // 编辑界面：true=添加模式，false=修改模式
    QString m_currentPatientId; // 当前选中患者ID
    QString m_loginUsername; // 当前登录用户名
};

#endif // MAINWINDOW_H
