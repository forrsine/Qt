#include "mainwindow.h"
#include <QFont>
#include <QHeaderView>
#include <QUuid>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_isAddMode(true)
{
    setWindowTitle("医院诊疗系统用户信息管理");
    setFixedSize(1000, 700); // 固定窗口大小
    initUI();
}

MainWindow::~MainWindow()
{
}

void MainWindow::initUI()
{
    m_stackedWidget = new QStackedWidget(this);
    setCentralWidget(m_stackedWidget);

    // 添加所有界面到切换容器
    m_stackedWidget->addWidget(createLoginWidget());
    m_stackedWidget->addWidget(createMainWidget());
    m_stackedWidget->addWidget(createPatientManagerWidget());
    m_stackedWidget->addWidget(createPatientEditWidget(true));

    // 默认显示登录界面
    m_stackedWidget->setCurrentIndex(0);
}

QWidget* MainWindow::createLoginWidget()
{
    QWidget* widget = new QWidget();
    QVBoxLayout* vLayout = new QVBoxLayout(widget);
    vLayout->setSpacing(30);
    vLayout->setContentsMargins(300, 150, 300, 150);

    // 标题
    QLabel* titleLabel = new QLabel("欢迎使用诊疗测试系统");
    QFont titleFont;
    titleFont.setPointSize(20);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignCenter);
    vLayout->addWidget(titleLabel);

    // 用户名输入
    QHBoxLayout* usernameLayout = new QHBoxLayout();
    QLabel* usernameLabel = new QLabel("用户名：");
    usernameLabel->setFont(QFont("Arial", 12));
    m_loginUsernameEdit = new QLineEdit();
    m_loginUsernameEdit->setPlaceholderText("请输入用户名");
    m_loginUsernameEdit->setFixedHeight(35);
    usernameLayout->addWidget(usernameLabel);
    usernameLayout->addWidget(m_loginUsernameEdit);
    vLayout->addLayout(usernameLayout);

    // 密码输入
    QHBoxLayout* passwordLayout = new QHBoxLayout();
    QLabel* passwordLabel = new QLabel("密码：");
    passwordLabel->setFont(QFont("Arial", 12));
    m_loginPasswordEdit = new QLineEdit();
    m_loginPasswordEdit->setEchoMode(QLineEdit::Password);
    m_loginPasswordEdit->setPlaceholderText("请输入密码");
    m_loginPasswordEdit->setFixedHeight(35);
    passwordLayout->addWidget(passwordLabel);
    passwordLayout->addWidget(m_loginPasswordEdit);
    vLayout->addLayout(passwordLayout);

    // 按钮布局
    QHBoxLayout* btnLayout = new QHBoxLayout();
    m_loginUsernameEdit->setText("admin"); // 默认填充管理员用户名
    m_loginPasswordEdit->setText("123456"); // 默认填充密码

    QPushButton* loginBtn = new QPushButton("登录");
    loginBtn->setFixedSize(100, 40);
    loginBtn->setFont(QFont("Arial", 12));
    connect(loginBtn, &QPushButton::clicked, this, &MainWindow::onLoginBtnClicked);

    QPushButton* registerBtn = new QPushButton("注册");
    registerBtn->setFixedSize(100, 40);
    registerBtn->setFont(QFont("Arial", 12));
    connect(registerBtn, &QPushButton::clicked, this, &MainWindow::onRegisterBtnClicked);

    btnLayout->addStretch();
    btnLayout->addWidget(loginBtn);
    btnLayout->addSpacing(50);
    btnLayout->addWidget(registerBtn);
    btnLayout->addStretch();
    vLayout->addLayout(btnLayout);

    // 添加开发者信息（左下角）
    QLabel* devLabel = new QLabel("开发者：学号 2023414300118 | 姓名 谢鑫");
    devLabel->setFont(QFont("Arial", 10));
    vLayout->addWidget(devLabel, 0, Qt::AlignBottom | Qt::AlignLeft);

    return widget;
}

QWidget* MainWindow::createMainWidget()
{
    QWidget* widget = new QWidget();
    QVBoxLayout* vLayout = new QVBoxLayout(widget);
    vLayout->setContentsMargins(0, 0, 0, 0);

    // 顶部工具栏
    QWidget* toolBarWidget = new QWidget();
    toolBarWidget->setStyleSheet("background-color: #2c3e50;");
    toolBarWidget->setFixedHeight(60);
    QHBoxLayout* toolBarLayout = new QHBoxLayout(toolBarWidget);
    toolBarLayout->setContentsMargins(30, 0, 30, 0);

    QPushButton* patientBtn = new QPushButton("患者管理");
    patientBtn->setFixedSize(120, 40);
    patientBtn->setStyleSheet("color:white; font-size:14px; background-color: transparent;");
    connect(patientBtn, &QPushButton::clicked, this, &MainWindow::onPatientManagerBtnClicked);

    QPushButton* deptBtn = new QPushButton("科室管理");
    deptBtn->setFixedSize(120, 40);
    deptBtn->setStyleSheet("color:white; font-size:14px; background-color: transparent;");
    connect(deptBtn, &QPushButton::clicked, this, &MainWindow::onDepartmentManagerBtnClicked);

    QPushButton* doctorBtn = new QPushButton("医生管理");
    doctorBtn->setFixedSize(120, 40);
    doctorBtn->setStyleSheet("color:white; font-size:14px; background-color: transparent;");
    connect(doctorBtn, &QPushButton::clicked, this, &MainWindow::onDoctorManagerBtnClicked);

    QLabel* userLabel = new QLabel(QString("当前用户：%1").arg(m_loginUsername));
    userLabel->setStyleSheet("color:white; font-size:14px;");

    toolBarLayout->addWidget(patientBtn);
    toolBarLayout->addWidget(deptBtn);
    toolBarLayout->addWidget(doctorBtn);
    toolBarLayout->addStretch();
    toolBarLayout->addWidget(userLabel);

    // 主内容区域
    QWidget* contentWidget = new QWidget();
    QVBoxLayout* contentLayout = new QVBoxLayout(contentWidget);
    QLabel* welcomeLabel = new QLabel("欢迎使用医院诊疗系统");
    welcomeLabel->setFont(QFont("Arial", 18, QFont::Bold));
    welcomeLabel->setAlignment(Qt::AlignCenter);
    contentLayout->addWidget(welcomeLabel);

    // 开发者信息
    QLabel* devLabel = new QLabel("开发者：学号 2023414300118 | 姓名 谢鑫");
    devLabel->setFont(QFont("Arial", 10));
    contentLayout->addWidget(devLabel, 0, Qt::AlignBottom | Qt::AlignRight);

    vLayout->addWidget(toolBarWidget);
    vLayout->addWidget(contentWidget, 1);

    return widget;
}

QWidget* MainWindow::createPatientManagerWidget()
{
    QWidget* widget = new QWidget();
    QVBoxLayout* vLayout = new QVBoxLayout(widget);
    vLayout->setContentsMargins(20, 20, 20, 20);
    vLayout->setSpacing(20);

    // 查询区域
    QHBoxLayout* queryLayout = new QHBoxLayout();
    QLabel* queryLabel = new QLabel("查询：");
    queryLabel->setFont(QFont("Arial", 12));
    m_patientQueryEdit = new QLineEdit();
    m_patientQueryEdit->setPlaceholderText("输入姓名/身份证/手机号查询");
    m_patientQueryEdit->setFixedHeight(35);
    m_queryPatientBtn = new QPushButton("查找");
    m_queryPatientBtn->setFixedSize(80, 35);
    connect(m_queryPatientBtn, &QPushButton::clicked, this, &MainWindow::onQueryPatientBtnClicked);

    queryLayout->addWidget(queryLabel);
    queryLayout->addWidget(m_patientQueryEdit);
    queryLayout->addWidget(m_queryPatientBtn);
    vLayout->addLayout(queryLayout);

    // 按钮区域
    QHBoxLayout* btnLayout = new QHBoxLayout();
    m_addPatientBtn = new QPushButton("添加");
    m_editPatientBtn = new QPushButton("修改");
    m_deletePatientBtn = new QPushButton("删除");
    m_addPatientBtn->setFixedSize(80, 35);
    m_editPatientBtn->setFixedSize(80, 35);
    m_deletePatientBtn->setFixedSize(80, 35);

    connect(m_addPatientBtn, &QPushButton::clicked, this, &MainWindow::onAddPatientBtnClicked);
    connect(m_editPatientBtn, &QPushButton::clicked, this, &MainWindow::onEditPatientBtnClicked);
    connect(m_deletePatientBtn, &QPushButton::clicked, this, &MainWindow::onDeletePatientBtnClicked);

    btnLayout->addWidget(m_addPatientBtn);
    btnLayout->addWidget(m_editPatientBtn);
    btnLayout->addWidget(m_deletePatientBtn);
    btnLayout->addStretch();
    vLayout->addLayout(btnLayout);

    // 患者列表表格
    m_patientTable = new QTableWidget();
    m_patientTable->setColumnCount(9);
    QStringList headers = {"ID", "身份证号", "姓名", "性别", "出生日期", "身高(cm)", "体重(kg)", "手机号", "年龄"};
    m_patientTable->setHorizontalHeaderLabels(headers);
    m_patientTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_patientTable->setRowCount(0);
    m_patientTable->setSelectionBehavior(QAbstractItemView::SelectRows); // 整行选择
    vLayout->addWidget(m_patientTable, 1);

    // 开发者信息
    QLabel* devLabel = new QLabel("开发者：学号 2023414300118 | 姓名 谢鑫");
    devLabel->setFont(QFont("Arial", 10));
    vLayout->addWidget(devLabel, 0, Qt::AlignBottom | Qt::AlignRight);

    // 初始化加载患者列表
    refreshPatientList();

    return widget;
}

QWidget* MainWindow::createPatientEditWidget(bool isAdd)
{
    m_isAddMode = isAdd;
    QWidget* widget = new QWidget();
    QVBoxLayout* vLayout = new QVBoxLayout(widget);
    vLayout->setContentsMargins(30, 30, 30, 30);
    vLayout->setSpacing(25);

    // 标题
    QLabel* titleLabel = new QLabel(isAdd ? "添加患者信息" : "修改患者信息");
    QFont titleFont;
    titleFont.setPointSize(16);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    vLayout->addWidget(titleLabel, 0, Qt::AlignCenter);

    // 表单布局（4行2列）
    QGridLayout* formLayout = new QGridLayout();
    formLayout->setSpacing(20);
    formLayout->setColumnStretch(0, 1);
    formLayout->setColumnStretch(1, 3);

    // ID
    QLabel* idLabel = new QLabel("ID：");
    idLabel->setFont(QFont("Arial", 12));
    m_editIdEdit = new QLineEdit();
    m_editIdEdit->setFixedHeight(35);
    if (isAdd) {
        // 添加模式：自动生成32位UUID作为ID
        m_editIdEdit->setText(QUuid::createUuid().toString().replace("{", "").replace("}", "").replace("-", ""));
        m_editIdEdit->setReadOnly(true); // ID不可编辑
    }
    formLayout->addWidget(idLabel, 0, 0, Qt::AlignRight);
    formLayout->addWidget(m_editIdEdit, 0, 1);

    // 身份证号
    QLabel* idCardLabel = new QLabel("身份证号：");
    idCardLabel->setFont(QFont("Arial", 12));
    m_editIdCardEdit = new QLineEdit();
    m_editIdCardEdit->setPlaceholderText("请输入18位身份证号");
    m_editIdCardEdit->setFixedHeight(35);
    formLayout->addWidget(idCardLabel, 1, 0, Qt::AlignRight);
    formLayout->addWidget(m_editIdCardEdit, 1, 1);

    // 姓名
    QLabel* nameLabel = new QLabel("姓名：");
    nameLabel->setFont(QFont("Arial", 12));
    m_editNameEdit = new QLineEdit();
    m_editNameEdit->setPlaceholderText("请输入患者姓名");
    m_editNameEdit->setFixedHeight(35);
    formLayout->addWidget(nameLabel, 2, 0, Qt::AlignRight);
    formLayout->addWidget(m_editNameEdit, 2, 1);

    // 性别
    QLabel* sexLabel = new QLabel("性别：");
    sexLabel->setFont(QFont("Arial", 12));
    m_editSexCombo = new QComboBox();
    m_editSexCombo->addItems({"女", "男"});
    m_editSexCombo->setFixedHeight(35);
    formLayout->addWidget(sexLabel, 3, 0, Qt::AlignRight);
    formLayout->addWidget(m_editSexCombo, 3, 1);

    // 出生日期
    QLabel* dobLabel = new QLabel("出生日期：");
    dobLabel->setFont(QFont("Arial", 12));
    m_editDobEdit = new QDateEdit();
    m_editDobEdit->setDate(QDate::fromString("2000/01/01", "yyyy/MM/dd"));
    m_editDobEdit->setCalendarPopup(true);
    m_editDobEdit->setFixedHeight(35);
    formLayout->addWidget(dobLabel, 4, 0, Qt::AlignRight);
    formLayout->addWidget(m_editDobEdit, 4, 1);

    // 身高
    QLabel* heightLabel = new QLabel("身高(cm)：");
    heightLabel->setFont(QFont("Arial", 12));
    m_editHeightEdit = new QLineEdit("0");
    m_editHeightEdit->setPlaceholderText("请输入身高");
    m_editHeightEdit->setFixedHeight(35);
    formLayout->addWidget(heightLabel, 5, 0, Qt::AlignRight);
    formLayout->addWidget(m_editHeightEdit, 5, 1);

    // 体重
    QLabel* weightLabel = new QLabel("体重(kg)：");
    weightLabel->setFont(QFont("Arial", 12));
    m_editWeightEdit = new QLineEdit("0");
    m_editWeightEdit->setPlaceholderText("请输入体重");
    m_editWeightEdit->setFixedHeight(35);
    formLayout->addWidget(weightLabel, 6, 0, Qt::AlignRight);
    formLayout->addWidget(m_editWeightEdit, 6, 1);

    // 手机号
    QLabel* phoneLabel = new QLabel("手机号：");
    phoneLabel->setFont(QFont("Arial", 12));
    m_editPhoneEdit = new QLineEdit();
    m_editPhoneEdit->setPlaceholderText("请输入手机号");
    m_editPhoneEdit->setFixedHeight(35);
    formLayout->addWidget(phoneLabel, 7, 0, Qt::AlignRight);
    formLayout->addWidget(m_editPhoneEdit, 7, 1);

    // 年龄
    QLabel* ageLabel = new QLabel("年龄：");
    ageLabel->setFont(QFont("Arial", 12));
    m_editAgeEdit = new QLineEdit("0");
    m_editAgeEdit->setPlaceholderText("请输入年龄");
    m_editAgeEdit->setFixedHeight(35);
    formLayout->addWidget(ageLabel, 8, 0, Qt::AlignRight);
    formLayout->addWidget(m_editAgeEdit, 8, 1);

    vLayout->addLayout(formLayout);

    // 按钮布局
    QHBoxLayout* btnLayout = new QHBoxLayout();
    m_savePatientBtn = new QPushButton("保存");
    m_cancelEditBtn = new QPushButton("取消");
    m_savePatientBtn->setFixedSize(100, 40);
    m_cancelEditBtn->setFixedSize(100, 40);
    m_savePatientBtn->setFont(QFont("Arial", 12));
    m_cancelEditBtn->setFont(QFont("Arial", 12));

    connect(m_savePatientBtn, &QPushButton::clicked, this, &MainWindow::onSavePatientBtnClicked);
    connect(m_cancelEditBtn, &QPushButton::clicked, this, &MainWindow::onCancelEditBtnClicked);

    btnLayout->addStretch();
    btnLayout->addWidget(m_savePatientBtn);
    btnLayout->addSpacing(50);
    btnLayout->addWidget(m_cancelEditBtn);
    btnLayout->addStretch();
    vLayout->addLayout(btnLayout);

    return widget;
}

void MainWindow::refreshPatientList(const QString &queryStr)
{
    // 清空表格
    m_patientTable->setRowCount(0);

    // 从数据库查询患者数据
    QSqlQuery query = DataBaseManager::getInstance()->getPatients(queryStr);
    int row = 0;
    while (query.next()) {
        m_patientTable->insertRow(row);

        // 填充数据
        m_patientTable->setItem(row, 0, new QTableWidgetItem(query.value("ID").toString()));
        m_patientTable->setItem(row, 1, new QTableWidgetItem(query.value("ID_CARD").toString()));
        m_patientTable->setItem(row, 2, new QTableWidgetItem(query.value("NAME").toString()));
        m_patientTable->setItem(row, 3, new QTableWidgetItem(query.value("SEX").toInt() == 0 ? "女" : "男"));
        m_patientTable->setItem(row, 4, new QTableWidgetItem(query.value("DOB").toString()));
        m_patientTable->setItem(row, 5, new QTableWidgetItem(QString::number(query.value("HEIGHT").toDouble())));
        m_patientTable->setItem(row, 6, new QTableWidgetItem(QString::number(query.value("WEIGHT").toDouble())));
        m_patientTable->setItem(row, 7, new QTableWidgetItem(query.value("MOBILEPHONE").toString()));
        m_patientTable->setItem(row, 8, new QTableWidgetItem(QString::number(query.value("AGE").toInt())));

        // 设置表格项不可编辑
        for (int col = 0; col < 9; col++) {
            m_patientTable->item(row, col)->setFlags(m_patientTable->item(row, col)->flags() & ~Qt::ItemIsEditable);
        }

        row++;
    }
}

void MainWindow::clearEditForm()
{
    m_editIdEdit->clear();
    m_editIdCardEdit->clear();
    m_editNameEdit->clear();
    m_editSexCombo->setCurrentIndex(0);
    m_editDobEdit->setDate(QDate::fromString("2000/01/01", "yyyy/MM/dd"));
    m_editHeightEdit->setText("0");
    m_editWeightEdit->setText("0");
    m_editPhoneEdit->clear();
    m_editAgeEdit->setText("0");
}

// 登录按钮点击事件
void MainWindow::onLoginBtnClicked()
{
    QString username = m_loginUsernameEdit->text().trimmed();
    QString password = m_loginPasswordEdit->text().trimmed();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "警告", "用户名或密码不能为空！");
        return;
    }

    // 验证登录
    if (DataBaseManager::getInstance()->verifyLogin(username, password)) {
        m_loginUsername = username;
        QMessageBox::information(this, "成功", "登录成功！");
        // 切换到主界面
        m_stackedWidget->setCurrentIndex(1);
        // 更新主界面用户信息（重新创建主界面以刷新用户名）
        m_stackedWidget->removeWidget(m_stackedWidget->widget(1));
        m_stackedWidget->insertWidget(1, createMainWidget());
    } else {
        QMessageBox::critical(this, "失败", "用户名或密码错误！");
    }
}

// 注册按钮点击事件（简化版：直接添加用户）
void MainWindow::onRegisterBtnClicked()
{
    QString username = m_loginUsernameEdit->text().trimmed();
    QString password = m_loginPasswordEdit->text().trimmed();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "警告", "用户名或密码不能为空！");
        return;
    }

    QSqlQuery query;
    query.exec(QString("SELECT * FROM User WHERE USERNAME='%1'").arg(username));
    if (query.next()) {
        QMessageBox::warning(this, "警告", "用户名已存在！");
        return;
    }

    query.exec(QString("INSERT INTO User (USERNAME, PASSWORD, FULLNAME) VALUES ('%1', '%2', '普通用户')")
                   .arg(username).arg(password));
    QMessageBox::information(this, "成功", "注册成功！请登录");
    clearEditForm();
}

// 切换到患者管理界面
void MainWindow::onPatientManagerBtnClicked()
{
    refreshPatientList(); // 刷新患者列表
    m_stackedWidget->setCurrentIndex(2);
}

// 科室管理（选做：仅提示）
void MainWindow::onDepartmentManagerBtnClicked()
{
    QMessageBox::information(this, "提示", "科室管理功能（选做）尚未实现！");
}

// 医生管理（选做：仅提示）
void MainWindow::onDoctorManagerBtnClicked()
{
    QMessageBox::information(this, "提示", "医生管理功能（选做）尚未实现！");
}

// 查询患者
void MainWindow::onQueryPatientBtnClicked()
{
    QString queryStr = m_patientQueryEdit->text().trimmed();
    refreshPatientList(queryStr);
}

// 添加患者
void MainWindow::onAddPatientBtnClicked()
{
    // 重新创建添加界面（确保是添加模式）
    m_stackedWidget->removeWidget(m_stackedWidget->widget(3));
    m_stackedWidget->insertWidget(3, createPatientEditWidget(true));
    m_stackedWidget->setCurrentIndex(3);
}

// 修改患者
void MainWindow::onEditPatientBtnClicked()
{
    // 获取选中行
    int selectedRow = m_patientTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "警告", "请选择要修改的患者！");
        return;
    }

    // 获取选中患者ID
    m_currentPatientId = m_patientTable->item(selectedRow, 0)->text();
    // 查询患者详情
    QSqlQuery query;
    query.exec(QString("SELECT * FROM Patient WHERE ID='%1'").arg(m_currentPatientId));
    if (!query.next()) {
        QMessageBox::critical(this, "失败", "获取患者信息失败！");
        return;
    }

    // 重新创建修改界面
    m_stackedWidget->removeWidget(m_stackedWidget->widget(3));
    m_stackedWidget->insertWidget(3, createPatientEditWidget(false));

    // 填充表单数据
    m_editIdEdit->setText(query.value("ID").toString());
    m_editIdEdit->setReadOnly(true); // 修改模式下ID不可编辑
    m_editIdCardEdit->setText(query.value("ID_CARD").toString());
    m_editNameEdit->setText(query.value("NAME").toString());
    m_editSexCombo->setCurrentIndex(query.value("SEX").toInt());
    m_editDobEdit->setDate(QDate::fromString(query.value("DOB").toString(), "yyyy/MM/dd"));
    m_editHeightEdit->setText(QString::number(query.value("HEIGHT").toDouble()));
    m_editWeightEdit->setText(QString::number(query.value("WEIGHT").toDouble()));
    m_editPhoneEdit->setText(query.value("MOBILEPHONE").toString());
    m_editAgeEdit->setText(QString::number(query.value("AGE").toInt()));

    // 切换到编辑界面
    m_stackedWidget->setCurrentIndex(3);
}

// 删除患者
void MainWindow::onDeletePatientBtnClicked()
{
    int selectedRow = m_patientTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "警告", "请选择要删除的患者！");
        return;
    }

    QString patientId = m_patientTable->item(selectedRow, 0)->text();
    QString patientName = m_patientTable->item(selectedRow, 2)->text();

    if (QMessageBox::question(this, "确认", QString("确定要删除患者「%1」吗？").arg(patientName),
                              QMessageBox::Yes | QMessageBox::No) == QMessageBox::No) {
        return;
    }

    // 执行删除
    if (DataBaseManager::getInstance()->deletePatient(patientId)) {
        QMessageBox::information(this, "成功", "删除成功！");
        // 记录操作日志
        DataBaseManager::getInstance()->addOperationRecord("", m_loginUsername, QString("删除患者：%1").arg(patientName));
        refreshPatientList();
    } else {
        QMessageBox::critical(this, "失败", "删除失败！");
    }
}

// 保存患者信息（添加/修改）
void MainWindow::onSavePatientBtnClicked()
{
    // 表单验证
    QString id = m_editIdEdit->text().trimmed();
    QString idCard = m_editIdCardEdit->text().trimmed();
    QString name = m_editNameEdit->text().trimmed();
    int sex = m_editSexCombo->currentIndex();
    QString dob = m_editDobEdit->date().toString("yyyy/MM/dd");
    double height = m_editHeightEdit->text().toDouble();
    double weight = m_editWeightEdit->text().toDouble();
    QString phone = m_editPhoneEdit->text().trimmed();
    int age = m_editAgeEdit->text().toInt();

    if (idCard.isEmpty() || idCard.length() != 18) {
        QMessageBox::warning(this, "警告", "请输入有效的18位身份证号！");
        return;
    }
    if (name.isEmpty()) {
        QMessageBox::warning(this, "警告", "姓名不能为空！");
        return;
    }
    if (height <= 0 || weight <= 0) {
        QMessageBox::warning(this, "警告", "身高和体重必须大于0！");
        return;
    }
    if (phone.isEmpty() || phone.length() != 11) {
        QMessageBox::warning(this, "警告", "请输入有效的11位手机号！");
        return;
    }
    if (age <= 0 || age > 120) {
        QMessageBox::warning(this, "警告", "请输入有效的年龄！");
        return;
    }

    bool success = false;
    QString event = "";
    if (m_isAddMode) {
        // 添加模式
        success = DataBaseManager::getInstance()->addPatient(id, idCard, name, sex, dob, height, weight, phone, age);
        event = QString("添加患者：%1").arg(name);
    } else {
        // 修改模式
        success = DataBaseManager::getInstance()->updatePatient(id, idCard, name, sex, dob, height, weight, phone, age);
        event = QString("修改患者：%1").arg(name);
    }

    if (success) {
        QMessageBox::information(this, "成功", m_isAddMode ? "添加成功！" : "修改成功！");
        // 记录操作日志
        DataBaseManager::getInstance()->addOperationRecord("", m_loginUsername, event);
        // 切换回患者管理界面并刷新列表
        refreshPatientList();
        m_stackedWidget->setCurrentIndex(2);
    } else {
        QMessageBox::critical(this, "失败", m_isAddMode ? "添加失败！" : "修改失败！");
    }
}

// 取消编辑
void MainWindow::onCancelEditBtnClicked()
{
    m_stackedWidget->setCurrentIndex(2);
}
