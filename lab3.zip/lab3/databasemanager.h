#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QString>
#include <QVariant>
#include <QDateTime>

class DataBaseManager
{
public:
    // 单例模式获取实例
    static DataBaseManager* getInstance();
    ~DataBaseManager();

    // 数据库连接状态
    bool isConnected() const;

    // 用户登录验证
    bool verifyLogin(const QString& username, const QString& password);

    // 患者信息操作
    QSqlQuery getPatients(const QString& queryStr = ""); // 查询患者（支持条件查询）
    bool addPatient(const QString& id, const QString& idCard, const QString& name,
                    int sex, const QString& dob, double height, double weight,
                    const QString& phone, int age);
    bool updatePatient(const QString& id, const QString& idCard, const QString& name,
                       int sex, const QString& dob, double height, double weight,
                       const QString& phone, int age);
    bool deletePatient(const QString& id);

    // 操作记录（选做功能）
    bool addOperationRecord(const QString& userId, const QString& username, const QString& event);

private:
    DataBaseManager(); // 私有构造函数（单例）
    QSqlDatabase m_db;
    static DataBaseManager* m_instance;

    // 创建数据表
    bool createTables();
};

#endif // DATABASEMANAGER_H
