#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>  // 文本编辑控件
#include <QAction>         // 菜单/工具栏动作
#include <QToolBar>        // 工具栏
#include <QMenuBar>        // 菜单栏
#include <QStatusBar>      // 状态栏
#include <QDialog>         // 对话框基类
#include <QLabel>          // 标签（用于对话框文本）
#include <QLineEdit>       // 输入框（用于查找/替换）
#include <QPushButton>     // 按钮
#include <QRadioButton>    // 单选按钮（查找方向）
#include <QHBoxLayout>     // 水平布局
#include <QVBoxLayout>     // 垂直布局
#include <QFileDialog>     // 文件选择对话框
#include <QFontDialog>     // 字体选择对话框
#include <QColorDialog>    // 颜色选择对话框
#include <QMessageBox>     // 消息提示框
#include <QTextCursor>     // 文本光标（用于查找/选中）

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow() = default;

private slots:
    // 1. 文件操作槽函数
    void onNewFile();     // 新建文件
    void onOpenFile();    // 打开文件
    void onSaveFile();    // 保存文件
    void onSaveAsFile();  // 另存为
    void onExit();        // 退出

    // 2. 编辑操作槽函数
    void onUndo();        // 撤销
    void onRedo();        // 恢复
    void onCut();         // 剪切
    void onCopy();        // 复制
    void onPaste();       // 粘贴
    void onFind();        // 查找
    void onReplace();     // 替换
    void onSelectAll();   // 全选

    // 3. 格式操作槽函数
    void onWordWrap();    // 自动换行
    void onSetFont();     // 设置字体
    void onSetFontColor();// 设置字体颜色
    void onSetFontBgColor();// 设置字体背景色
    void onSetEditorBgColor();// 设置编辑器背景色

    // 4. 查看操作槽函数
    void onShowToolBar(); // 显示/隐藏工具栏
    void onShowStatusBar();// 显示/隐藏状态栏

    // 5. 帮助操作槽函数
    void onAbout();       // 关于对话框

    // 6. 辅助槽函数
    void onTextChanged(); // 文本变化时更新窗口标题（标记未保存）
    void updateStatusBar();// 更新状态栏信息（行列号、文本长度）

private:
    // 核心组件声明
    QTextEdit *textEdit;  // 文本编辑区（核心控件）
    QAction *actNew, *actOpen, *actSave, *actSaveAs, *actExit; // 文件组动作
    QAction *actUndo, *actRedo, *actCut, *actCopy, *actPaste, *actFind, *actReplace, *actSelectAll; // 编辑组动作
    QAction *actWordWrap, *actSetFont, *actSetFontColor, *actSetFontBgColor, *actSetEditorBgColor; // 格式组动作
    QAction *actShowToolBar, *actShowStatusBar; // 查看组动作
    QAction *actAbout; // 帮助组动作

    QToolBar *fileToolBar; // 文件工具栏
    QToolBar *editToolBar; // 编辑工具栏
    QToolBar *formatToolBar; // 格式工具栏

    QString currentFilePath; // 当前打开文件的路径（用于保存时判断是否已存在文件）
    bool isTextModified;     // 文本是否被修改（用于更新窗口标题）

    // 对话框声明（查找、替换、关于）
    void createFindDialog();  // 创建查找对话框
    void createReplaceDialog();// 创建替换对话框
    void createAboutDialog(); // 创建关于对话框

    QDialog *findDialog;      // 查找对话框实例
    QLineEdit *findEdit;      // 查找输入框
    QRadioButton *rbUp, *rbDown; // 查找方向单选按钮
    QPushButton *btnFindNext, *btnFindCancel; // 查找对话框按钮

    QDialog *replaceDialog;   // 替换对话框实例
    QLineEdit *replaceEdit;   // 替换输入框
    QPushButton *btnReplace, *btnReplaceAll, *btnReplaceCancel; // 替换对话框按钮

    QDialog *aboutDialog;     // 关于对话框实例
};

#endif // MAINWINDOW_H
