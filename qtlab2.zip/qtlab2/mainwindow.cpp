#include "MainWindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    currentFilePath(""),  // 初始无打开文件
    isTextModified(false) // 初始文本未修改
{
    // -------------------------- 1. 创建核心文本编辑区 --------------------------
    textEdit = new QTextEdit(this);
    setCentralWidget(textEdit); // 将文本区设为窗口中心组件
    textEdit->setLineWrapMode(QTextEdit::NoWrap); // 初始不自动换行
    textEdit->setPlaceholderText("请输入文本..."); // 占位提示

    // 文本变化时触发的信号：更新“未保存”状态和状态栏
    connect(textEdit, &QTextEdit::textChanged, this, &MainWindow::onTextChanged);
    connect(textEdit, &QTextEdit::cursorPositionChanged, this, &MainWindow::updateStatusBar);

    // -------------------------- 2. 创建Action（菜单/工具栏的“动作”） --------------------------
    // 2.1 文件组Action（带快捷键和提示）
    actNew = new QAction("新建(&N)", this);
    actNew->setShortcut(QKeySequence::New); // 快捷键 Ctrl+N
    actNew->setStatusTip("创建新文本文件");

    actOpen = new QAction("打开(&O)", this);
    actOpen->setShortcut(QKeySequence::Open); // Ctrl+O
    actOpen->setStatusTip("打开已存在的文本文件");

    actSave = new QAction("保存(&S)", this);
    actSave->setShortcut(QKeySequence::Save); // Ctrl+S
    actSave->setStatusTip("保存当前文本文件");

    actSaveAs = new QAction("另存为(&A)", this);
    actSaveAs->setStatusTip("将当前文本另存为新文件");

    actExit = new QAction("退出(&X)", this);
    actExit->setStatusTip("退出应用程序");

    // 2.2 编辑组Action
    actUndo = new QAction("撤销(&U)", this);
    actUndo->setShortcut(QKeySequence::Undo); // Ctrl+Z
    actUndo->setStatusTip("撤销上一步操作");
    actUndo->setEnabled(false); // 初始无操作，禁用撤销

    actRedo = new QAction("恢复(&R)", this);
    actRedo->setShortcut(QKeySequence::Redo); // Ctrl+Shift+Z
    actRedo->setStatusTip("恢复上一步撤销的操作");
    actRedo->setEnabled(false); // 初始禁用恢复

    actCut = new QAction("剪切(&T)", this);
    actCut->setShortcut(QKeySequence::Cut); // Ctrl+X
    actCut->setStatusTip("剪切选中的文本");
    actCut->setEnabled(false); // 无选中文本时禁用

    actCopy = new QAction("复制(&C)", this);
    actCopy->setShortcut(QKeySequence::Copy); // Ctrl+C
    actCopy->setStatusTip("复制选中的文本");
    actCopy->setEnabled(false); // 初始禁用

    actPaste = new QAction("粘贴(&P)", this);
    actPaste->setShortcut(QKeySequence::Paste); // Ctrl+V
    actPaste->setStatusTip("粘贴剪贴板中的文本");

    actFind = new QAction("查找(&F)", this);
    actFind->setShortcut(QKeySequence::Find); // Ctrl+F
    actFind->setStatusTip("查找指定文本");

    actReplace = new QAction("替换(&H)", this);
    actReplace->setShortcut(QKeySequence("Ctrl+H")); // Ctrl+H
    actReplace->setStatusTip("替换指定文本");

    actSelectAll = new QAction("全选(&A)", this);
    actSelectAll->setShortcut(QKeySequence::SelectAll); // Ctrl+A
    actSelectAll->setStatusTip("选中所有文本");

    // 2.3 格式组Action
    actWordWrap = new QAction("自动换行(&W)", this);
    actWordWrap->setShortcut(QKeySequence("Ctrl+L")); // Ctrl+L
    actWordWrap->setStatusTip("开启/关闭自动换行");
    actWordWrap->setCheckable(true); // 可勾选（标记是否开启）

    actSetFont = new QAction("字体(&F)", this);
    actSetFont->setStatusTip("设置文本字体和大小");

    actSetFontColor = new QAction("字体颜色", this);
    actSetFontColor->setStatusTip("设置文本颜色");

    actSetFontBgColor = new QAction("字体背景色", this);
    actSetFontBgColor->setStatusTip("设置文本背景色");

    actSetEditorBgColor = new QAction("编辑器背景色", this);
    actSetEditorBgColor->setStatusTip("设置编辑器背景色");

    // 2.4 查看组Action
    actShowToolBar = new QAction("工具栏(&T)", this);
    actShowToolBar->setStatusTip("显示/隐藏工具栏");
    actShowToolBar->setCheckable(true);
    actShowToolBar->setChecked(true); // 初始显示工具栏

    actShowStatusBar = new QAction("状态栏(&S)", this);
    actShowStatusBar->setStatusTip("显示/隐藏状态栏");
    actShowStatusBar->setCheckable(true);
    actShowStatusBar->setChecked(true); // 初始显示状态栏

    // 2.5 帮助组Action
    actAbout = new QAction("关于(&A)", this);
    actAbout->setStatusTip("查看应用程序信息");

    // -------------------------- 3. 创建菜单栏 --------------------------
    QMenuBar *menuBar = new QMenuBar(this);
    setMenuBar(menuBar);

    // 3.1 “文件”菜单
    QMenu *menuFile = menuBar->addMenu("文件(&F)");
    menuFile->addAction(actNew);
    menuFile->addAction(actOpen);
    menuFile->addAction(actSave);
    menuFile->addAction(actSaveAs);
    menuFile->addSeparator(); // 分隔线
    menuFile->addAction(actExit);

    // 3.2 “编辑”菜单
    QMenu *menuEdit = menuBar->addMenu("编辑(&E)");
    menuEdit->addAction(actUndo);
    menuEdit->addAction(actRedo);
    menuEdit->addSeparator();
    menuEdit->addAction(actCut);
    menuEdit->addAction(actCopy);
    menuEdit->addAction(actPaste);
    menuEdit->addSeparator();
    menuEdit->addAction(actFind);
    menuEdit->addAction(actReplace);
    menuEdit->addSeparator();
    menuEdit->addAction(actSelectAll);

    // 3.3 “格式”菜单
    QMenu *menuFormat = menuBar->addMenu("格式(&O)");
    menuFormat->addAction(actWordWrap);
    menuFormat->addAction(actSetFont);
    menuFormat->addAction(actSetFontColor);
    menuFormat->addAction(actSetFontBgColor);
    menuFormat->addAction(actSetEditorBgColor);

    // 3.4 “查看”菜单
    QMenu *menuView = menuBar->addMenu("查看(&V)");
    menuView->addAction(actShowToolBar);
    menuView->addAction(actShowStatusBar);

    // 3.5 “帮助”菜单
    QMenu *menuHelp = menuBar->addMenu("帮助(&H)");
    menuHelp->addAction(actAbout);

    // -------------------------- 4. 创建工具栏 --------------------------
    // 4.1 文件工具栏（只放常用文件操作）
    fileToolBar = addToolBar("文件工具栏");
    fileToolBar->addAction(actNew);
    fileToolBar->addAction(actOpen);
    fileToolBar->addAction(actSave);
    fileToolBar->addSeparator();
    fileToolBar->addAction(actExit);

    // 4.2 编辑工具栏
    editToolBar = addToolBar("编辑工具栏");
    editToolBar->addAction(actUndo);
    editToolBar->addAction(actRedo);
    editToolBar->addSeparator();
    editToolBar->addAction(actCut);
    editToolBar->addAction(actCopy);
    editToolBar->addAction(actPaste);
    editToolBar->addSeparator();
    editToolBar->addAction(actFind);
    editToolBar->addAction(actReplace);

    // 4.3 格式工具栏
    formatToolBar = addToolBar("格式工具栏");
    formatToolBar->addAction(actWordWrap);
    formatToolBar->addAction(actSetFont);
    formatToolBar->addAction(actSetFontColor);
    formatToolBar->addAction(actSetEditorBgColor);

    // -------------------------- 5. 创建状态栏 --------------------------
    QStatusBar *statusBar = new QStatusBar(this);
    setStatusBar(statusBar);
    updateStatusBar(); // 初始更新状态栏信息

    // -------------------------- 6. 初始化对话框（提前创建，避免重复创建） --------------------------
    createFindDialog();
    createReplaceDialog();
    createAboutDialog();

    // -------------------------- 7. 绑定Action与槽函数（功能触发逻辑） --------------------------
    // 7.1 文件操作绑定
    connect(actNew, &QAction::triggered, this, &MainWindow::onNewFile);
    connect(actOpen, &QAction::triggered, this, &MainWindow::onOpenFile);
    connect(actSave, &QAction::triggered, this, &MainWindow::onSaveFile);
    connect(actSaveAs, &QAction::triggered, this, &MainWindow::onSaveAsFile);
    connect(actExit, &QAction::triggered, this, &MainWindow::onExit);

    // 7.2 编辑操作绑定
    connect(actUndo, &QAction::triggered, textEdit, &QTextEdit::undo);
    connect(actRedo, &QAction::triggered, textEdit, &QTextEdit::redo);
    connect(actCut, &QAction::triggered, textEdit, &QTextEdit::cut);
    connect(actCopy, &QAction::triggered, textEdit, &QTextEdit::copy);
    connect(actPaste, &QAction::triggered, textEdit, &QTextEdit::paste);
    connect(actFind, &QAction::triggered, this, [=]() { findDialog->show(); }); // 显示查找对话框
    connect(actReplace, &QAction::triggered, this, [=]() { replaceDialog->show(); }); // 显示替换对话框
    connect(actSelectAll, &QAction::triggered, textEdit, &QTextEdit::selectAll);

    // 7.3 格式操作绑定
    connect(actWordWrap, &QAction::triggered, this, &MainWindow::onWordWrap);
    connect(actSetFont, &QAction::triggered, this, &MainWindow::onSetFont);
    connect(actSetFontColor, &QAction::triggered, this, &MainWindow::onSetFontColor);
    connect(actSetFontBgColor, &QAction::triggered, this, &MainWindow::onSetFontBgColor);
    connect(actSetEditorBgColor, &QAction::triggered, this, &MainWindow::onSetEditorBgColor);

    // 7.4 查看操作绑定
    connect(actShowToolBar, &QAction::triggered, this, &MainWindow::onShowToolBar);
    connect(actShowStatusBar, &QAction::triggered, this, &MainWindow::onShowStatusBar);

    // 7.5 帮助操作绑定
    connect(actAbout, &QAction::triggered, this, [=]() { aboutDialog->show(); }); // 显示关于对话框

    // 7.6 编辑按钮使能控制（根据文本选中状态更新）
    connect(textEdit, &QTextEdit::selectionChanged, this, [=]() {
        bool hasSelection = !textEdit->textCursor().selectedText().isEmpty();
        actCut->setEnabled(hasSelection);
        actCopy->setEnabled(hasSelection);
    });

    // 7.7 撤销/恢复使能控制（根据文本编辑状态更新）
    connect(textEdit, &QTextEdit::undoAvailable, actUndo, &QAction::setEnabled);
    connect(textEdit, &QTextEdit::redoAvailable, actRedo, &QAction::setEnabled);

    // -------------------------- 8. 设置窗口初始属性 --------------------------
    setWindowTitle("新建文本文件 - 简单文本编辑器");
    resize(800, 600); // 初始窗口大小
}

// -------------------------- 对话框创建函数 --------------------------
// 1. 创建查找对话框
void MainWindow::createFindDialog()
{
    findDialog = new QDialog(this);
    findDialog->setWindowTitle("查找");
    findDialog->setFixedSize(350, 150); // 固定大小，不允许拉伸

    // 布局：垂直布局（标签+输入框 → 单选按钮 → 按钮）
    QVBoxLayout *vLayout = new QVBoxLayout(findDialog);

    // 1.1 查找目标：标签+输入框（水平布局）
    QHBoxLayout *hLayout1 = new QHBoxLayout();
    QLabel *labFind = new QLabel("查找目标:", findDialog);
    findEdit = new QLineEdit(findDialog);
    hLayout1->addWidget(labFind);
    hLayout1->addWidget(findEdit);
    vLayout->addLayout(hLayout1);

    // 1.2 查找方向：单选按钮（水平布局）
    QHBoxLayout *hLayout2 = new QHBoxLayout();
    rbUp = new QRadioButton("向上(U)", findDialog);
    rbDown = new QRadioButton("向下(D)", findDialog);
    rbDown->setChecked(true); // 默认向下查找
    hLayout2->addWidget(rbUp);
    hLayout2->addWidget(rbDown);
    vLayout->addLayout(hLayout2);

    // 1.3 按钮：查找下一个 + 取消（水平布局）
    QHBoxLayout *hLayout3 = new QHBoxLayout();
    btnFindNext = new QPushButton("查找下一个(F)", findDialog);
    btnFindCancel = new QPushButton("取消", findDialog);
    hLayout3->addWidget(btnFindNext);
    hLayout3->addWidget(btnFindCancel);
    vLayout->addLayout(hLayout3);

    // 绑定查找按钮逻辑（点击“查找下一个”执行查找）
    connect(btnFindNext, &QPushButton::clicked, this, &MainWindow::onFind);
    // 绑定取消按钮逻辑（关闭对话框）
    connect(btnFindCancel, &QPushButton::clicked, findDialog, &QDialog::close);
    // 输入框按Enter键触发查找
    connect(findEdit, &QLineEdit::returnPressed, this, &MainWindow::onFind);
}

// 2. 创建替换对话框
void MainWindow::createReplaceDialog()
{
    replaceDialog = new QDialog(this);
    replaceDialog->setWindowTitle("替换");
    replaceDialog->setFixedSize(400, 200);

    // 布局：垂直布局（查找目标 → 替换为 → 方向 → 按钮）
    QVBoxLayout *vLayout = new QVBoxLayout(replaceDialog);

    // 2.1 查找目标：标签+输入框
    QHBoxLayout *hLayout1 = new QHBoxLayout();
    QLabel *labFind = new QLabel("查找目标:", replaceDialog);
    findEdit = new QLineEdit(replaceDialog); // 复用查找输入框（也可新建）
    hLayout1->addWidget(labFind);
    hLayout1->addWidget(findEdit);
    vLayout->addLayout(hLayout1);

    // 2.2 替换为：标签+输入框
    QHBoxLayout *hLayout2 = new QHBoxLayout();
    QLabel *labReplace = new QLabel("替换为:", replaceDialog);
    replaceEdit = new QLineEdit(replaceDialog);
    hLayout2->addWidget(labReplace);
    hLayout2->addWidget(replaceEdit);
    vLayout->addLayout(hLayout2);

    // 2.3 查找方向：单选按钮
    QHBoxLayout *hLayout3 = new QHBoxLayout();
    rbUp = new QRadioButton("向上(U)", replaceDialog);
    rbDown = new QRadioButton("向下(D)", replaceDialog);
    rbDown->setChecked(true);
    hLayout3->addWidget(rbUp);
    hLayout3->addWidget(rbDown);
    vLayout->addLayout(hLayout3);

    // 2.4 按钮：查找下一个 + 替换 + 全部替换 + 取消
    QHBoxLayout *hLayout4 = new QHBoxLayout();
    btnFindNext = new QPushButton("查找下一个(F)", replaceDialog);
    btnReplace = new QPushButton("替换(R)", replaceDialog);
    btnReplaceAll = new QPushButton("全部替换(A)", replaceDialog);
    btnReplaceCancel = new QPushButton("取消", replaceDialog);
    hLayout4->addWidget(btnFindNext);
    hLayout4->addWidget(btnReplace);
    hLayout4->addWidget(btnReplaceAll);
    hLayout4->addWidget(btnReplaceCancel);
    vLayout->addLayout(hLayout4);

    // 绑定按钮逻辑
    connect(btnFindNext, &QPushButton::clicked, this, &MainWindow::onFind);
    connect(btnReplace, &QPushButton::clicked, this, &MainWindow::onReplace);
    connect(btnReplaceAll, &QPushButton::clicked, this, [=]() {
        // 全部替换逻辑：循环查找并替换所有匹配内容
        QString findText = findEdit->text();
        QString replaceText = replaceEdit->text();
        if (findText.isEmpty()) return;

        textEdit->selectAll();
        QString allText = textEdit->toPlainText();
        int replaceCount = allText.count(findText); // 统计替换次数
        allText.replace(findText, replaceText);
        textEdit->setPlainText(allText);

        QMessageBox::information(this, "替换完成", QString("共替换 %1 处匹配内容").arg(replaceCount));
    });
    connect(btnReplaceCancel, &QPushButton::clicked, replaceDialog, &QDialog::close);
}

// 3. 创建关于对话框
void MainWindow::createAboutDialog()
{
    aboutDialog = new QDialog(this);
    aboutDialog->setWindowTitle("关于");
    aboutDialog->setFixedSize(300, 200);

    // 布局：垂直布局（文本标签 + OK按钮）
    QVBoxLayout *vLayout = new QVBoxLayout(aboutDialog);

    // 3.1 关于文本（替换为你的信息）
    QLabel *labAbout = new QLabel(
        "小牛文本编辑\n\n"
        "开发者: 谢鑫\n"
        "学号: 2023414300118\n"
        ,
        aboutDialog
        );
    labAbout->setAlignment(Qt::AlignCenter); // 文本居中
    vLayout->addWidget(labAbout);

    // 3.2 OK按钮
    QPushButton *btnOk = new QPushButton("OK", aboutDialog);
    vLayout->addWidget(btnOk);

    // 绑定OK按钮逻辑（关闭对话框）
    connect(btnOk, &QPushButton::clicked, aboutDialog, &QDialog::close);
}

// -------------------------- 核心功能槽函数 --------------------------
// 1. 文件操作
void MainWindow::onNewFile()
{
    // 如果当前文本已修改，提示保存
    if (isTextModified) {
        int ret = QMessageBox::question(this, "提示", "当前文本未保存，是否保存？",
                                        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            onSaveFile(); // 保存当前文件
        } else if (ret == QMessageBox::Cancel) {
            return; // 取消新建
        }
    }
    // 新建文件：清空文本、重置路径和修改状态
    textEdit->clear();
    currentFilePath = "";
    isTextModified = false;
    setWindowTitle("新建文本文件 - 简单文本编辑器");
}

void MainWindow::onOpenFile()
{
    // 提示保存当前未保存文本
    if (isTextModified) {
        int ret = QMessageBox::question(this, "提示", "当前文本未保存，是否保存？",
                                        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            onSaveFile();
        } else if (ret == QMessageBox::Cancel) {
            return;
        }
    }
    // 打开文件选择对话框（只允许选择文本文件）
    QString filePath = QFileDialog::getOpenFileName(this, "打开文件", "", "文本文件 (*.txt);;所有文件 (*.*)");
    if (filePath.isEmpty()) return; // 取消选择

    // 读取文件内容并显示到文本区
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        textEdit->setPlainText(in.readAll()); // 读取所有文本
        file.close();

        // 更新文件路径和窗口标题
        currentFilePath = filePath;
        isTextModified = false;
        QString fileName = QFileInfo(filePath).fileName(); // 获取文件名（不含路径）
        setWindowTitle(QString("%1 - 简单文本编辑器").arg(fileName));
    } else {
        QMessageBox::warning(this, "错误", "无法打开文件：" + file.errorString());
    }
}

void MainWindow::onSaveFile()
{
    // 如果已有文件路径，直接保存；否则触发“另存为”
    if (currentFilePath.isEmpty()) {
        onSaveAsFile();
        return;
    }
    // 写入文件
    QFile file(currentFilePath);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << textEdit->toPlainText(); // 写入文本区内容
        file.close();

        // 更新修改状态和窗口标题
        isTextModified = false;
        QString fileName = QFileInfo(currentFilePath).fileName();
        setWindowTitle(QString("%1 - 简单文本编辑器").arg(fileName));
    } else {
        QMessageBox::warning(this, "错误", "无法保存文件：" + file.errorString());
    }
}

void MainWindow::onSaveAsFile()
{
    // 打开“另存为”对话框
    QString filePath = QFileDialog::getSaveFileName(this, "另存为", "", "文本文件 (*.txt);;所有文件 (*.*)");
    if (filePath.isEmpty()) return;

    // 写入文件（同保存逻辑）
    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << textEdit->toPlainText();
        file.close();

        // 更新文件路径和标题
        currentFilePath = filePath;
        isTextModified = false;
        QString fileName = QFileInfo(filePath).fileName();
        setWindowTitle(QString("%1 - 简单文本编辑器").arg(fileName));
    } else {
        QMessageBox::warning(this, "错误", "无法保存文件：" + file.errorString());
    }
}

void MainWindow::onExit()
{
    // 退出前提示保存未修改文本
    if (isTextModified) {
        int ret = QMessageBox::question(this, "提示", "当前文本未保存，是否保存？",
                                        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            onSaveFile();
        } else if (ret == QMessageBox::Cancel) {
            return;
        }
    }
    close(); // 关闭窗口（退出应用）
}

// 2. 编辑操作（查找/替换，其他操作已在构造函数中直接绑定文本区方法）
void MainWindow::onFind()
{
    QString findText = findEdit->text();
    if (findText.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入查找内容！");
        return;
    }

    QTextCursor cursor = textEdit->textCursor();
    QTextDocument::FindFlags flags;
    // 根据单选按钮设置查找方向
    if (rbUp->isChecked()) {
        flags |= QTextDocument::FindBackward; // 向上查找（反向）
    }

    // 执行查找：如果找到，选中匹配内容；否则提示
    bool found = textEdit->find(findText, flags);
    if (!found) {
        QMessageBox::information(this, "查找完成", "未找到指定内容：" + findText);
        // 查找失败后重置光标到文档开头（可选）
        cursor.movePosition(QTextCursor::Start);
        textEdit->setTextCursor(cursor);
    }
}

void MainWindow::onReplace()
{
    QString findText = findEdit->text();
    QString replaceText = replaceEdit->text();
    if (findText.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入查找内容！");
        return;
    }

    QTextCursor cursor = textEdit->textCursor();
    // 如果当前选中内容等于查找内容，直接替换；否则先查找
    if (cursor.selectedText() == findText) {
        cursor.insertText(replaceText); // 替换选中内容
        onFind(); // 替换后继续查找下一个
    } else {
        // 先查找，找到后再替换
        bool found = textEdit->find(findText, rbUp->isChecked() ? QTextDocument::FindBackward : QTextDocument::FindFlags());
        if (found) {
            cursor = textEdit->textCursor();
            cursor.insertText(replaceText);
            onFind();
        } else {
            QMessageBox::information(this, "替换完成", "未找到指定内容：" + findText);
        }
    }
}

// 3. 格式操作
void MainWindow::onWordWrap()
{
    // 切换自动换行模式（勾选则自动换行，否则不换行）
    if (actWordWrap->isChecked()) {
        textEdit->setLineWrapMode(QTextEdit::WidgetWidth); // 按窗口宽度自动换行
    } else {
        textEdit->setLineWrapMode(QTextEdit::NoWrap); // 不自动换行
    }
}

void MainWindow::onSetFont()
{
    // 打开字体选择对话框（初始字体为当前文本字体）
    bool ok;
    QFont font = QFontDialog::getFont(&ok, textEdit->font(), this, "选择字体");
    if (ok) {
        textEdit->setFont(font); // 应用选择的字体
    }
}

void MainWindow::onSetFontColor()
{
    // 打开颜色选择对话框（初始颜色为当前文本颜色）
    QColor color = QColorDialog::getColor(textEdit->textColor(), this, "选择字体颜色");
    if (color.isValid()) {
        textEdit->setTextColor(color); // 应用字体颜色
    }
}

void MainWindow::onSetFontBgColor()
{
    // 打开颜色选择对话框（初始颜色为当前文本背景色）
    QColor color = QColorDialog::getColor(textEdit->textBackgroundColor(), this, "选择字体背景色");
    if (color.isValid()) {
        textEdit->setTextBackgroundColor(color); // 应用字体背景色
    }
}

void MainWindow::onSetEditorBgColor()
{
    // 打开颜色选择对话框（初始颜色为当前编辑器背景色）
    QColor color = QColorDialog::getColor(textEdit->palette().base().color(), this, "选择编辑器背景色");
    if (color.isValid()) {
        QPalette palette = textEdit->palette();
        palette.setColor(QPalette::Base, color); // 设置编辑器背景色（Base为文本区背景）
        textEdit->setPalette(palette);
    }
}

// 4. 查看操作
void MainWindow::onShowToolBar()
{
    // 切换工具栏显示/隐藏（所有工具栏同步）
    bool isShow = actShowToolBar->isChecked();
    fileToolBar->setVisible(isShow);
    editToolBar->setVisible(isShow);
    formatToolBar->setVisible(isShow);
}

void MainWindow::onShowStatusBar()
{
    // 切换状态栏显示/隐藏
    statusBar()->setVisible(actShowStatusBar->isChecked());
}

// 5. 辅助操作
void MainWindow::onTextChanged()
{
    // 文本修改时，在窗口标题前加“*”标记未保存
    if (!isTextModified) {
        isTextModified = true;
        QString currentTitle = windowTitle();
        if (!currentTitle.startsWith("*")) {
            setWindowTitle("*" + currentTitle);
        }
    }
    updateStatusBar(); // 文本变化时更新状态栏（文本长度）
}

void MainWindow::updateStatusBar()
{
    // 获取文本信息：行数、列数、文本长度
    QTextCursor cursor = textEdit->textCursor();
    int line = cursor.blockNumber() + 1; // 行号从1开始（blockNumber从0开始）
    int column = cursor.columnNumber() + 1; // 列号从1开始
    int textLength = textEdit->toPlainText().length();

    // 更新状态栏文本
    statusBar()->showMessage(QString("Ln: %1 Col: %2 | 长度: %3 字符").arg(line).arg(column).arg(textLength));
}

// 撤销操作
void MainWindow::onUndo()
{
    textEdit->undo();
}

// 恢复操作
void MainWindow::onRedo()
{
    textEdit->redo();
}

// 剪切操作
void MainWindow::onCut()
{
    textEdit->cut();
}

// 复制操作
void MainWindow::onCopy()
{
    textEdit->copy();
}

// 粘贴操作
void MainWindow::onPaste()
{
    textEdit->paste();
}

// 全选操作
void MainWindow::onSelectAll()
{
    textEdit->selectAll();
}

// 关于对话框操作
void MainWindow::onAbout()
{
    aboutDialog->show();
}
